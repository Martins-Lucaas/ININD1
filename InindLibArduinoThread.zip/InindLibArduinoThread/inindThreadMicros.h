//https://blog.eletrogate.com/interrupcao-o-que-e-como-utilizar-arduin/
//https://www.squids.com.br/arduino/index.php/projetos-arduino/projetos-squids/basico/263-projeto-79-interrupcao-por-timer-no-arduino-alarme-sensor-de-toque

//O timer0 é utilizado pelo Arduino para funções como delay(), millis() e micros(). Então não se deve utilizar esse timer para evitar comprometer essas funções.
//O timer1 no Arduino UNO esse é o timer utilizado pela biblioteca de controle de servos. Caso você não esteja utilizando essa biblioteca, esse timer está livre para ser utilizado para outros propósitos. No Arduino Mega esse timer só será utilizado para controlar os servos se você estiver usando mais de 12 servos. (timer utilizado no projeto)
//O timer2 é utilizado pela função tone(). Então se você não precisar da função tone() esse timer está livre para outras aplicações.
#include <stdarg.h>

using CallbackFuncMicros = void(*)(); //Definição de tipo para nossa callback
volatile CallbackFuncMicros threadFuncMicros[5]; 
volatile int numThreadMicros,threadIntervalMicros[5],threadTimeMicros[5];

void threadSetupMicros(CallbackFuncMicros callbackMicros,int threadIntervalFuncMicros,...){
  numThreadMicros= 1;
  va_list args;
  va_start (args, threadIntervalFuncMicros);
  
  while(va_arg(args, CallbackFuncMicros)){ 
    va_arg(args, int);
    numThreadMicros++;
  }

  //Dynamically allocate memory using malloc()
  //threadTime     = (int *) malloc(numThread * sizeof(int));
  //threadInterval = (int *) malloc(numThread * sizeof(int));
  //threadFuncMicros     = (CallbackFuncMicros *) malloc(numThread * sizeof(CallbackFuncMicros));
  
  threadTimeMicros[0]     = 0;
  threadFuncMicros[0]     = callbackMicros;
  threadIntervalMicros[0] = threadIntervalFuncMicros;

  va_start (args, threadIntervalFuncMicros);
  for(int i=1;i<numThreadMicros;i++){
    threadTimeMicros[i]     = 0;
    threadFuncMicros[i]     = va_arg(args, CallbackFuncMicros);
    threadIntervalMicros[i] = va_arg(args,int);
  }
  va_end(args);
  cli();              //Desliga as interrupções para não haver error durante a configuração 
  TCCR1A = 0b01000000;//Modo comparação
  TCCR1B = 0b00001010;//Configuração do prescaler em 8 e OCR1A register is used to manipulate the counter resolution
  TIMSK1 = 0b00000001;//Habilita a interrupção por overflow do timer 
  OCR1A  = 0b00000010;//Compare match register = [16,000,000Hz/ (prescaler * desired interrupt frequency) ] - 1
  sei();              //Habilita interrupções globais
}

ISR(TIMER1_OVF_vect){
  for(int i=0;i < numThreadMicros;i++){
    if(threadTimeMicros[i] >= threadIntervalMicros[i]) {
      threadFuncMicros[i]();
      threadTimeMicros[i] = 0;
    }
    else threadTimeMicros[i]++;
  } 
}

